import React, { useState, useRef, useEffect } from "react";
import { Eye, EyeOff, Settings, Package, Plus, Trash2, Edit2, X, Check, ChevronDown, ChevronUp, Save, Upload, Image, CreditCard, AlertCircle, Store, Star, ArrowUp, ArrowDown, Bike, FileSpreadsheet, UserCircle, Gift, Users } from "lucide-react";
import {
  updateStoreSettings,
  createProduct, updateProduct, deleteProduct, updateProductFeatured, updateProductOrder,
  createVariant, updateVariant, deleteVariant,
  uploadProductImage, toggleStoreOpen,
  checkSlugAvailable, updateStoreSlug, applyGstRateToAllProducts,
  fetchCatalogProducts, fetchCatalogLinkStatus, updateProductAvailability,
} from "../lib/api";
import { slugify } from "./AuthGate";
import DeliveryBoyManager from "./DeliveryBoyManager";
import ShopStaffManager from "./ShopStaffManager";
import CsvBulkUploadModal from "./CsvBulkUpload";
import CategoryFields from "./CategoryFields";
import CatalogPicker from "./CatalogPicker";
import AccountSettings from "./AccountSettings";
import ComboManager from "./ComboManager";
import TableQR from "./TableQR";
import { validateVeriloSettings } from "../lib/verilo";

export default function AdminPanel({ store, products, user, onRefresh, initialTab }) {
  return <AdminContent store={store} products={products} user={user} onRefresh={onRefresh} initialTab={initialTab} />;
}

function AdminContent({ store, products, user, onRefresh, initialTab }) {
  const [tab, setTab] = useState(initialTab || "products");
  // Tab-strip: jab aur tabs side mein chhupe hon to right edge par fade+arrow dikhao
  const tabStripRef = useRef(null);
  const [moreRight, setMoreRight] = useState(false);
  const updateMoreRight = () => {
    const el = tabStripRef.current;
    if (el) setMoreRight(el.scrollWidth - el.scrollLeft - el.clientWidth > 6);
  };
  useEffect(() => {
    updateMoreRight();
    window.addEventListener("resize", updateMoreRight);
    return () => window.removeEventListener("resize", updateMoreRight);
  }, []);
  useEffect(() => {
    // chuna hua tab screen me aa jaye
    const el = tabStripRef.current;
    const btn = el && el.querySelector('[data-active="true"]');
    if (btn && btn.scrollIntoView) btn.scrollIntoView({ inline: "nearest", block: "nearest" });
    updateMoreRight();
  }, [tab]);

  // Salon/Beauty Parlour (booking-mode) mein delivery boy ka concept
  // hai hi nahi (appointment hai, delivery nahi) — isliye sirf isi
  // business type ke liye "Delivery Staff" tab hide hota hai. Baaki
  // SAARE business types (kirana/restaurant/fashion/hardware/bakery/
  // etc) mein yeh tab bilkul pehle jaisa hi dikhta hai.
  const tabs = [
    { id: "products", label: "Products", icon: <Package size={14} /> },
    { id: "combos", label: "Combos", icon: <Gift size={14} /> },
    ...(isBookingCategory(store.business_type) ? [] : [{ id: "delivery", label: "Delivery", icon: <Bike size={14} /> }]),
    ...(store.business_type === "restaurant" ? [{ id: "tableqr", label: "Table QR", icon: <Package size={14} /> }] : []),
    { id: "staff", label: "Staff", icon: <Users size={14} /> },
    { id: "settings", label: "Store Settings", icon: <Settings size={14} /> },
    { id: "account", label: "Account", icon: <UserCircle size={14} /> },
    { id: "subscription", label: "Subscription", icon: <CreditCard size={14} /> },
  ];

  return (
    <div style={{ maxWidth: "600px", margin: "0 auto", padding: "16px 18px 40px" }}>
      <div style={{ position: "relative", marginBottom: "16px" }}>
      <div ref={tabStripRef} onScroll={updateMoreRight} style={{ display: "flex", gap: "2px", borderBottom: "1px solid #E3DECF", overflowX: "auto", scrollbarWidth: "none" }}>
        {tabs.map((t) => (
          <button key={t.id} data-active={tab === t.id ? "true" : "false"} onClick={() => setTab(t.id)} style={{
            display: "flex", alignItems: "center", gap: "6px", padding: "9px 12px", fontSize: "12px", fontWeight: 700,
            border: "none", background: "transparent", cursor: "pointer", whiteSpace: "nowrap",
            color: tab === t.id ? "#1B4332" : "#8B8576",
            borderBottom: tab === t.id ? "2.5px solid #1B4332" : "2.5px solid transparent",
            marginBottom: "-1px",
          }}>
            {t.icon} {t.label}
          </button>
        ))}
      </div>
      {moreRight && (
        <div aria-hidden="true" style={{ position: "absolute", top: 0, right: 0, bottom: "1px", width: "34px", pointerEvents: "none", display: "flex", alignItems: "center", justifyContent: "flex-end", paddingRight: "2px", background: "linear-gradient(to right, rgba(245,243,236,0), #F7F5F0 70%)", color: "#1B4332", fontSize: "18px", fontWeight: 800 }}>›</div>
      )}
      </div>

      {tab === "products" && <ProductManager store={store} products={products} onRefresh={onRefresh} />}
      {tab === "combos" && <ComboManager store={store} products={products} />}
      {tab === "delivery" && <DeliveryBoyManager store={store} />}
      {tab === "staff" && <ShopStaffManager store={store} />}
      {tab === "tableqr" && <TableQR store={store} />}
      {tab === "settings" && <StoreSettingsForm store={store} onRefresh={onRefresh} />}
      {tab === "account" && <AccountSettings user={user} />}
      {tab === "subscription" && <SubscriptionPanel store={store} onRefresh={onRefresh} />}
    </div>
  );
}

import RazorpaySubscription from "./RazorpaySubscription";
import { getRenewalState, RENEWAL_WINDOW_DAYS } from "../lib/subscription";
import { getShoppingMode, getDiscountInfo, getUnitPresets, isBookingCategory } from "../lib/theme";
import { INDIAN_STATES } from "../lib/gst";

import { friendlyError } from "../lib/errors";
// ============================================================
// SUBSCRIPTION PANEL — Razorpay se real payment
// ============================================================
function SubscriptionPanel({ store, onRefresh }) {
  const [msg, setMsg] = useState(null);

  const renewal = getRenewalState(store);
  const isActive = store.is_active !== false;
  const expiry = store.subscription_expires_at ? new Date(store.subscription_expires_at) : null;
  const daysLeft = expiry ? Math.ceil((expiry - new Date()) / (1000 * 60 * 60 * 24)) : null;
  const isExpired = daysLeft !== null && daysLeft < 0;

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
      {/* Status Card */}
      <div style={{
        background: isActive && !isExpired ? "#E7F0EA" : "#FDECEA",
        border: `1px solid ${isActive && !isExpired ? "#1B4332" : "#B3261E"}`,
        borderRadius: "12px", padding: "16px 18px"
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "6px" }}>
          <div style={{ width: 10, height: 10, borderRadius: "50%", background: isActive && !isExpired ? "#1B4332" : "#B3261E" }} />
          <div style={{ fontWeight: 700, fontSize: "14px", color: isActive && !isExpired ? "#1B4332" : "#B3261E" }}>
            {isActive && !isExpired ? "Dukaan Active Hai ✅" : isExpired ? "Subscription Expire Ho Gayi ⚠️" : "Dukaan Paused Hai ⏸️"}
          </div>
        </div>
        {expiry && (
          <div style={{ fontSize: "12px", color: "#5C5747" }}>
            {isExpired
              ? `${Math.abs(daysLeft)} din pehle expire hua`
              : `${daysLeft} din baaki hain (${expiry.toLocaleDateString("en-IN")} tak)`}
          </div>
        )}
      </div>

      {msg && (
        <div style={{ padding: "10px 14px", borderRadius: "9px", background: msg.type === "success" ? "#E7F0EA" : "#FDECEA", color: msg.type === "success" ? "#1B4332" : "#B3261E", fontSize: "12.5px", fontWeight: 600 }}>
          {msg.text}
        </div>
      )}

      {/* Renewal ka waqt nahi aaya: payment options chhupe rehte hain */}
      {isActive && !isExpired && !renewal.due && (
        <div style={{ background: "#F7F5F0", borderRadius: "10px", padding: "12px 14px", fontSize: "12.5px", color: "#5C5747", lineHeight: 1.6 }}>
          {renewal.isFree
            ? "Is dukaan par abhi koi subscription charge nahi lagta."
            : `Aapka subscription chal raha hai. Renewal ka option expiry se ${RENEWAL_WINDOW_DAYS} din pehle (${renewal.renewalOpensOn.toLocaleDateString("en-IN")} se) khulega. Tab tak payment ki zaroorat nahi.`}
        </div>
      )}
      {renewal.expiringSoon && (
        <div style={{ background: "#FFF4DB", border: "1px solid #E8C877", borderRadius: "10px", padding: "11px 14px", fontSize: "12.5px", color: "#8A6A0F", fontWeight: 600 }}>
          ⚠️ Subscription {Math.max(renewal.daysLeft, 0)} din mein khatam hogi — neeche renew kar lein. Abhi renew karne par bachi hui validity mein naye mahine jud jaayenge.
        </div>
      )}

      {/* Razorpay Payment — sirf renewal ke waqt (ya AutoPay status) */}
      <RazorpaySubscription
        store={store}
        canPay={renewal.due}
        onSuccess={() => {
          setMsg({ type: "success", text: "Payment successful! Dukaan active ho gayi." });
          onRefresh();
        }}
      />
    </div>
  );
}

// ============================================================
// STORE SETTINGS
// ============================================================
function formatTimeRange(opensAt, closesAt) {
  const fmt = (t) => {
    if (!t) return "";
    const [h, m] = t.split(":").map(Number);
    const period = h >= 12 ? "PM" : "AM";
    const h12 = h % 12 === 0 ? 12 : h % 12;
    return `${String(h12).padStart(2, "0")}:${String(m).padStart(2, "0")} ${period}`;
  };
  return `${fmt(opensAt)} To ${fmt(closesAt)}`;
}

function StoreSettingsForm({ store, onRefresh }) {
  const [name, setName] = useState(store.name);
  const [whatsapp, setWhatsapp] = useState(store.whatsapp_number);
  const [upi, setUpi] = useState(store.upi_id || "");
  const [address, setAddress] = useState(store.address || "");
  const [logoUrl, setLogoUrl] = useState(store.logo_url || "");
  const [tagline, setTagline] = useState(store.tagline || "");
  const [timings, setTimings] = useState(store.timings || "");
  const [autoHours, setAutoHours] = useState(!!store.auto_hours_enabled);
  const [opensAt, setOpensAt] = useState(store.opens_at ? store.opens_at.slice(0, 5) : "09:00");
  const [closesAt, setClosesAt] = useState(store.closes_at ? store.closes_at.slice(0, 5) : "21:00");
  const [deliveryFee, setDeliveryFee] = useState(String(store.delivery_fee || 0));
  const [freeDeliveryAbove, setFreeDeliveryAbove] = useState(store.free_delivery_above != null ? String(store.free_delivery_above) : "");
  const [bannerImages, setBannerImages] = useState(store.banner_images || []);
  const [deliveryEnabled, setDeliveryEnabled] = useState(store.delivery_enabled !== false);
  const [gstEnabledSetting, setGstEnabledSetting] = useState(!!store.gst_enabled);
  const [gstPriceType, setGstPriceType] = useState(store.gst_price_type || "exclusive");
  const [gstState, setGstState] = useState(store.gst_state || "");
  const [gstin, setGstin] = useState(store.gstin || "");
  const [veriloOptIn, setVeriloOptIn] = useState(!!store.verilo_opt_in);
  const [veriloCity, setVeriloCity] = useState(store.city || "");
  const [veriloState, setVeriloState] = useState(store.state || "");
  const [veriloPincode, setVeriloPincode] = useState(store.pincode || "");
  const [bulkGstRate, setBulkGstRate] = useState("18");
  const [bulkApplying, setBulkApplying] = useState(false);
  const [bulkMsg, setBulkMsg] = useState("");

  const handleBulkApplyGst = async () => {
    if (!confirm(`Store ke SAARE products ka GST Rate ${bulkGstRate}% set kar dein? Yeh har product ko overwrite kar dega.`)) return;
    setBulkApplying(true);
    setBulkMsg("");
    try {
      const count = await applyGstRateToAllProducts(store.id, Number(bulkGstRate));
      setBulkMsg(`✓ ${count} product(s) update ho gaye.`);
    } catch (e) {
      setBulkMsg("Error: " + friendlyError(e));
    } finally {
      setBulkApplying(false);
    }
  };
  const [facebookUrl, setFacebookUrl] = useState(store.facebook_url || "");
  const [instagramUrl, setInstagramUrl] = useState(store.instagram_url || "");
  const [youtubeUrl, setYoutubeUrl] = useState(store.youtube_url || "");
  const [gmbUrl, setGmbUrl] = useState(store.gmb_url || "");
  const [mapsLink, setMapsLink] = useState(store.maps_link || "");
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const handleSave = async () => {
    const verilo = validateVeriloSettings({
      optIn: veriloOptIn, city: veriloCity, state: veriloState, pincode: veriloPincode,
      wasOptIn: !!store.verilo_opt_in, existingAt: store.verilo_opt_in_at || null,
    });
    if (!verilo.ok) {
      alert(verilo.error);
      return;
    }
    setSaving(true);
    setSaved(false);
    try {
      await updateStoreSettings(store.id, {
        ...verilo.values,
        name, whatsapp_number: whatsapp, upi_id: upi, address, logo_url: logoUrl || null, tagline: tagline || null,
        timings: autoHours ? formatTimeRange(opensAt, closesAt) : (timings || null),
        delivery_fee: Number(deliveryFee) || 0,
        free_delivery_above: freeDeliveryAbove.trim() === "" ? null : Number(freeDeliveryAbove),
        auto_hours_enabled: autoHours,
        opens_at: autoHours ? opensAt : null,
        closes_at: autoHours ? closesAt : null,
        banner_images: bannerImages.length > 0 ? bannerImages : null,
        facebook_url: facebookUrl.trim() || null,
        instagram_url: instagramUrl.trim() || null,
        youtube_url: youtubeUrl.trim() || null,
        gmb_url: gmbUrl.trim() || null,
        maps_link: mapsLink.trim() || null,
        delivery_enabled: deliveryEnabled,
        gst_enabled: gstEnabledSetting,
        gst_price_type: gstPriceType,
        gst_state: gstState || null,
        gstin: gstin.trim() || null,
      });
      setSaved(true);
      onRefresh();
      setTimeout(() => setSaved(false), 2500);
    } catch (e) {
      alert("Save nahi ho paaya: " + friendlyError(e));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
      <SlugChangeSection store={store} onRefresh={onRefresh} />
      <div style={{ background: "white", border: "1px solid #E3DECF", borderRadius: "12px", padding: "18px", display: "flex", flexDirection: "column", gap: "12px" }}>
      <StoreLogoPicker currentLogo={logoUrl} storeId={store.id} onChange={setLogoUrl} />
      <StorageUsageBar usedBytes={store.storage_used_bytes} limitBytes={store.storage_limit_bytes} />
      <Field label="Dukaan ka Naam" value={name} onChange={setName} />
      <Field label="Ek Line Tagline (naam ke neeche dikhegi, optional)" value={tagline} onChange={setTagline} placeholder="jaise Sabse sasta kirana, ghar tak!" />
      <Field label="WhatsApp Number (91 ke saath, jaise 919876543210)" value={whatsapp} onChange={setWhatsapp} />
      <Field label="UPI ID (jaise dukaan@upi)" value={upi} onChange={setUpi} placeholder="abhi optional hai" />
      <Field label="Address" value={address} onChange={setAddress} textarea />
      <div>
        <Field label="Google Maps Link (customer ko 'Get Directions' button dikhega, optional)" value={mapsLink} onChange={setMapsLink} placeholder="Google Maps app kholein → apni dukaan ki location par jaayein → Share karein → yahan paste karein" />
        <div style={{ fontSize: "10px", color: "#8B8576", marginTop: "3px" }}>
          Agar yeh khaali chhoda to Address se hi ek approximate map-link ban jaayega — exact pin ke liye yeh bharna behtar hai.
        </div>
      </div>
      {autoHours ? (
        <div>
          <div style={{ fontSize: "12px", fontWeight: 600, color: "#5C5747", marginBottom: "4px" }}>Khulne-Band hone ka Time (customer ko dikhega)</div>
          <div style={{ width: "100%", border: "1px solid #E3DECF", borderRadius: "8px", padding: "9px 11px", fontSize: "13px", background: "#F7F5F0", color: "#8B8576" }}>
            {formatTimeRange(opensAt, closesAt)} <span style={{ fontSize: "10.5px" }}>(automatic time se khud ban raha hai, neeche se badlein)</span>
          </div>
        </div>
      ) : (
        <Field label="Khulne-Band hone ka Time (customer ko dikhega, optional)" value={timings} onChange={setTimings} placeholder="jaise Roz subah 8 - raat 10 baje tak" textarea />
      )}
      <div style={{ borderTop: "1px solid #E3DECF", paddingTop: "12px", marginTop: "2px" }}>
        <div style={{ fontSize: "12px", fontWeight: 700, color: "#1A1A1A", marginBottom: "4px" }}>🖼️ Promotional Banners (customer ko top par dikhenge, optional)</div>
        <div style={{ fontSize: "10.5px", color: "#8B8576", marginBottom: "10px" }}>
          2-4 photos daalein (offers, naye products, festival greeting) — customer storefront ke top par ghoomti rahengi. Apni khud khichi photo hi daalein.
        </div>
        <MultiImagePicker images={bannerImages} storeId={store.id} onChange={setBannerImages} />
      </div>
      <div style={{ borderTop: "1px solid #E3DECF", paddingTop: "12px", marginTop: "2px" }}>
        <label style={{ display: "flex", alignItems: "center", gap: "8px", cursor: "pointer", marginBottom: autoHours ? "10px" : 0 }}>
          <input type="checkbox" checked={autoHours} onChange={(e) => setAutoHours(e.target.checked)} style={{ width: "16px", height: "16px" }} />
          <span style={{ fontSize: "12px", fontWeight: 700, color: "#1A1A1A" }}>🕐 Automatic Open/Close (samay ke hisaab se khud badle)</span>
        </label>
        <div style={{ fontSize: "10.5px", color: "#8B8576", marginBottom: autoHours ? "10px" : 0 }}>
          On karne par OPEN/BAND HAI badge apne aap set time ke hisaab se badlega — dashboard se manually tap karke badalna band ho jaayega.
        </div>
        {autoHours && (
          <div style={{ display: "flex", gap: "8px" }}>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: "11px", fontWeight: 600, color: "#5C5747", marginBottom: "4px" }}>Khulne ka Time</div>
              <input type="time" value={opensAt} onChange={(e) => setOpensAt(e.target.value)} style={{ width: "100%", border: "1px solid #E3DECF", borderRadius: "8px", padding: "9px 11px", fontSize: "12.5px", fontFamily: "inherit", outline: "none" }} />
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: "11px", fontWeight: 600, color: "#5C5747", marginBottom: "4px" }}>Band hone ka Time</div>
              <input type="time" value={closesAt} onChange={(e) => setClosesAt(e.target.value)} style={{ width: "100%", border: "1px solid #E3DECF", borderRadius: "8px", padding: "9px 11px", fontSize: "12.5px", fontFamily: "inherit", outline: "none" }} />
            </div>
          </div>
        )}
      </div>
      <div style={{ borderTop: "1px solid #E3DECF", paddingTop: "12px", marginTop: "2px" }}>
        <div style={{ fontSize: "12px", fontWeight: 700, color: "#1A1A1A", marginBottom: "10px" }}>🛵 Delivery Charge</div>
        <label style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "10px", cursor: "pointer" }}>
          <input type="checkbox" checked={deliveryEnabled} onChange={(e) => setDeliveryEnabled(e.target.checked)} style={{ width: "16px", height: "16px" }} />
          <span style={{ fontSize: "12px", fontWeight: 600 }}>Home Delivery denge</span>
        </label>
        {!deliveryEnabled && (
          <div style={{ fontSize: "10.5px", color: "#B3261E", background: "#FDECEA", borderRadius: "7px", padding: "8px 10px", marginBottom: "10px" }}>
            Home Delivery band hai — customer ko checkout mein sirf Pickup{store.business_type === "restaurant" ? "/Dine In" : ""} hi dikhega.
          </div>
        )}
        {deliveryEnabled && (
          <div style={{ display: "flex", gap: "8px" }}>
            <div style={{ flex: 1 }}>
              <Field label="Delivery Charge (₹)" value={deliveryFee} onChange={(v) => setDeliveryFee(v.replace(/[^\d.]/g, ""))} placeholder="jaise 20 (0 rakhein agar free hai)" />
            </div>
            <div style={{ flex: 1 }}>
              <Field label="Free Delivery Upar Kitne Rupaye Se (optional)" value={freeDeliveryAbove} onChange={(v) => setFreeDeliveryAbove(v.replace(/[^\d.]/g, ""))} placeholder="jaise 300" />
            </div>
          </div>
        )}
        <div style={{ fontSize: "10.5px", color: "#8B8576", marginTop: "4px" }}>
          Yeh sirf Home Delivery orders par lagta hai — Pickup (dukaan se khud lena) orders par kabhi nahi.
        </div>
      </div>
      <div style={{ borderTop: "1px solid #E3DECF", paddingTop: "12px", marginTop: "2px" }}>
        <div style={{ fontSize: "12px", fontWeight: 700, color: "#1A1A1A", marginBottom: "4px" }}>🧾 GST / Tax (optional)</div>
        <div style={{ fontSize: "10.5px", color: "#8B8576", marginBottom: "10px" }}>
          Sirf tab enable karein jab aap GST-registered hain aur bill par GST dikhana chahte hain. Band rakhne par sab kuch pehle jaisa hi chalega.
        </div>
        <label style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "10px", cursor: "pointer" }}>
          <input type="checkbox" checked={gstEnabledSetting} onChange={(e) => setGstEnabledSetting(e.target.checked)} style={{ width: "16px", height: "16px" }} />
          <span style={{ fontSize: "12px", fontWeight: 600 }}>GST enable karein</span>
        </label>
        {gstEnabledSetting && (
          <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
            <div>
              <div style={{ fontSize: "11px", fontWeight: 600, color: "#5C5747", marginBottom: "4px" }}>Aapke product ki price kaisi hai?</div>
              <div style={{ display: "flex", gap: "8px" }}>
                {[["exclusive", "GST Exclusive (price ke upar GST judega)"], ["inclusive", "GST Inclusive (price mein GST shamil hai)"]].map(([v, l]) => (
                  <button key={v} type="button" onClick={() => setGstPriceType(v)} style={{ flex: 1, padding: "9px 8px", borderRadius: "8px", border: gstPriceType === v ? "1.5px solid #1B4332" : "1px solid #E3DECF", background: gstPriceType === v ? "#E7F0EA" : "white", color: gstPriceType === v ? "#1B4332" : "#5C5747", fontWeight: 700, fontSize: "11px", cursor: "pointer", lineHeight: 1.3 }}>
                    {l}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <div style={{ fontSize: "11px", fontWeight: 600, color: "#5C5747", marginBottom: "4px" }}>Aapki dukaan kis State mein hai? (CGST+SGST ya IGST decide karne ke liye)</div>
              <select value={gstState} onChange={(e) => setGstState(e.target.value)} style={inputStyle}>
                <option value="">State chunein</option>
                {INDIAN_STATES.map((st) => <option key={st} value={st}>{st}</option>)}
              </select>
            </div>
            <Field label="GSTIN (optional — bill par dikhega)" value={gstin} onChange={(v) => setGstin(v.toUpperCase())} placeholder="jaise 23ABCDE1234F1Z5" />
            <div style={{ fontSize: "10.5px", color: "#8B8576" }}>
              Ab har product/variant ke form mein "GST Rate" (0/5/12/18/28%) ka option dikhega. Jo product par rate set nahi hoga, woh 0% maana jaayega.
            </div>
            <div style={{ background: "#F7F5F0", borderRadius: "9px", padding: "10px 12px", display: "flex", flexDirection: "column", gap: "8px" }}>
              <div style={{ fontSize: "11px", fontWeight: 700, color: "#1A1A1A" }}>Sab Products Par Ek Saath GST Rate Apply Karein</div>
              <div style={{ fontSize: "10.5px", color: "#8B8576" }}>
                Har product mein alag-alag jaake set karne ke bajaye, ek hi rate saari products par ek click mein laga sakte hain. Baad mein kisi ek product ka rate alag chahiye ho to usko alag se edit kar sakte hain.
              </div>
              <div style={{ display: "flex", gap: "8px", alignItems: "center" }}>
                <select value={bulkGstRate} onChange={(e) => setBulkGstRate(e.target.value)} style={{ ...inputStyle, flex: 1 }}>
                  {[0, 5, 12, 18, 28].map((r) => <option key={r} value={String(r)}>{r}%</option>)}
                </select>
                <button type="button" onClick={handleBulkApplyGst} disabled={bulkApplying} style={{ background: "#1B4332", color: "white", border: "none", borderRadius: "8px", padding: "9px 14px", fontSize: "11.5px", fontWeight: 700, cursor: "pointer", whiteSpace: "nowrap" }}>
                  {bulkApplying ? "..." : "Sab Par Apply Karein"}
                </button>
              </div>
              {bulkMsg && <div style={{ fontSize: "11px", color: bulkMsg.startsWith("Error") ? "#B3261E" : "#1B4332", fontWeight: 600 }}>{bulkMsg}</div>}
            </div>
          </div>
        )}
      </div>
      <div style={{ borderTop: "1px solid #E3DECF", paddingTop: "12px", marginTop: "2px" }}>
        <div style={{ fontSize: "12px", fontWeight: 700, color: "#1A1A1A", marginBottom: "4px" }}>📱 Social Media Links (agar ho to, sab optional)</div>
        <div style={{ fontSize: "10.5px", color: "#8B8576", marginBottom: "10px" }}>
          Jo bhi bhar dein, uska icon customer storefront ke neeche (footer mein) dikhega. Khaali chhoda hua icon nahi dikhega.
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
          <Field label="Facebook Page Link" value={facebookUrl} onChange={setFacebookUrl} placeholder="https://facebook.com/aapki-dukaan" />
          <Field label="Instagram Link" value={instagramUrl} onChange={setInstagramUrl} placeholder="https://instagram.com/aapki-dukaan" />
          <Field label="YouTube Channel Link" value={youtubeUrl} onChange={setYoutubeUrl} placeholder="https://youtube.com/@aapki-dukaan" />
          <Field label="Google Business Profile Link" value={gmbUrl} onChange={setGmbUrl} placeholder="Google Maps par dukaan ki listing ka link" />
        </div>
      </div>
      <div style={{ borderTop: "1px solid #E3DECF", paddingTop: "12px", marginTop: "2px" }}>
        <div style={{ fontSize: "12px", fontWeight: 700, color: "#1A1A1A", marginBottom: "4px" }}>📍 Verilo par apni dukaan dikhayein (optional)</div>
        <div style={{ fontSize: "10.5px", color: "#8B8576", marginBottom: "10px" }}>
          Verilo ek local services directory hai jahan aas-paas ke log dukaan dhoondhte hain. ON karne par aapki dukaan wahan bhi dikh sakti hai — bina kisi extra charge ke.
        </div>
        <label style={{ display: "flex", alignItems: "center", gap: "8px", cursor: "pointer", marginBottom: "10px" }}>
          <input type="checkbox" checked={veriloOptIn} onChange={(e) => setVeriloOptIn(e.target.checked)} style={{ width: "16px", height: "16px" }} />
          <span style={{ fontSize: "12px", fontWeight: 600 }}>Haan, meri dukaan Verilo par dikhayein</span>
        </label>
        {veriloOptIn && (
          <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
            <Field label="City / Shehar" value={veriloCity} onChange={setVeriloCity} placeholder="jaise Anuppur" />
            <div>
              <div style={{ fontSize: "11px", fontWeight: 600, color: "#5C5747", marginBottom: "4px" }}>State</div>
              <select value={veriloState} onChange={(e) => setVeriloState(e.target.value)} style={inputStyle}>
                <option value="">State chunein</option>
                {INDIAN_STATES.map((st) => <option key={st} value={st}>{st}</option>)}
              </select>
            </div>
            <Field label="Pincode (6 digits)" value={veriloPincode} onChange={(v) => setVeriloPincode(v.replace(/[^0-9]/g, "").slice(0, 6))} placeholder="jaise 484224" />
            <div style={{ fontSize: "10.5px", color: "#8B8576" }}>
              Verilo par yeh dikhega: dukaan ka naam, tagline, logo, address, city, WhatsApp number, timings, Maps link aur social media links. UPI ID, GSTIN aur billing ki jaankari kabhi nahi dikhegi. Jab tak aapka Dukaan subscription active hai tabhi dukaan Verilo par dikhegi; subscription band hote hi apne aap hat jaayegi. Aap kabhi bhi yeh option OFF kar sakte hain.
            </div>
            {!(store.subscription_expires_at && new Date(store.subscription_expires_at) > new Date()) && (
              <div style={{ fontSize: "10.5px", color: "#B3261E", background: "#FDECEA", borderRadius: "7px", padding: "8px 10px" }}>
                Abhi aapka subscription active nahi hai, isliye subscription chalu hone tak dukaan Verilo par nahi dikhegi.
              </div>
            )}
          </div>
        )}
      </div>
      <button onClick={handleSave} disabled={saving} className="ddemo-btn" style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "8px", background: saved ? "#1B4332" : "#D4A24C", color: saved ? "white" : "#123026", fontWeight: 800, fontSize: "13.5px", border: "none", borderRadius: "10px", padding: "12px 0", cursor: "pointer", marginTop: "6px" }}>
        {saved ? <><Check size={15} /> Save Ho Gaya</> : <><Save size={15} /> {saving ? "Save ho raha hai..." : "Changes Save Karein"}</>}
      </button>
      <CloseShopSection store={store} onRefresh={onRefresh} />
      </div>
    </div>
  );
}

// ============================================================
// CLOSE SHOP — Store Settings ke andar. Sirf naye orders rokta hai
// (subscription chalta rehta hai). Dobara kholne ke liye upar ka OPEN button.
// ============================================================
function CloseShopSection({ store, onRefresh }) {
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState(null);
  const isActive = store.is_active !== false;
  const expired = store.subscription_expires_at && new Date(store.subscription_expires_at) < new Date();
  const isAuto = !!store.auto_hours_enabled;
  const isClosed = store.is_open === false;
  if (!isActive || expired) return null;

  const close = async () => {
    if (!confirm("Close your shop for now? Customers will not be able to place orders. Your subscription will keep running. To reopen, tap the OPEN button at the top.")) return;
    setBusy(true); setMsg(null);
    try {
      await toggleStoreOpen(store.id, false);
      setMsg({ type: "success", text: "Your shop is now closed for orders. Your subscription is not affected." });
      onRefresh();
    } catch (e) {
      setMsg({ type: "error", text: friendlyError(e) });
    } finally { setBusy(false); }
  };

  return (
    <div style={{ background: "white", border: "1px solid #F3C6C1", borderRadius: "12px", padding: "14px 16px", marginTop: "14px" }}>
      <div style={{ fontWeight: 700, fontSize: "13px", marginBottom: "4px" }}>Shop ko Band Karein (Orders Rokein)</div>
      <div style={{ fontSize: "11.5px", color: "#8B8576", lineHeight: 1.55, marginBottom: "10px" }}>
        Sirf naye orders band hote hain. Aapka subscription chalta rehta hai. Dobara kholne ke liye upar ka OPEN button dabayein.
        {isAuto ? " Abhi Auto timings chalu hain, isliye shop apne timing ke hisaab se khulti-band hoti hai. Manual close ke liye upar Settings me \"Auto timings\" band karke Save karein." : ""}
      </div>
      {msg && <div style={{ padding: "8px 12px", borderRadius: "8px", fontSize: "12px", fontWeight: 600, marginBottom: "10px", background: msg.type === "success" ? "#E7F0EA" : "#FDECEA", color: msg.type === "success" ? "#1B4332" : "#B3261E" }}>{msg.text}</div>}
      <button onClick={close} disabled={busy || isClosed || isAuto} style={{ width: "100%", background: "white", border: "1px solid #B3261E", color: "#B3261E", borderRadius: "9px", padding: "10px 0", fontSize: "12.5px", fontWeight: 700, cursor: busy || isClosed || isAuto ? "not-allowed" : "pointer", opacity: isClosed || isAuto ? 0.5 : 1 }}>
        {busy ? "Band ho raha hai..." : isAuto ? "Auto timings chalu hain — abhi manual close nahi ho sakta" : isClosed ? "Shop abhi band hai" : "⏸️ Close Shop (Stop Orders)"}
      </button>
    </div>
  );
}

// ============================================================
// URL SLUG CHANGE — alag section, apna save button, saaf warning ke
// saath (kyunki purane shared links tootne ka risk hota hai).
// ============================================================
function SlugChangeSection({ store, onRefresh }) {
  const [editing, setEditing] = useState(false);
  const [slug, setSlug] = useState(store.slug);
  const [status, setStatus] = useState(null); // null | 'checking' | 'available' | 'taken'
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  const RESERVED_SLUGS = new Set(["superadmin", "signup", "login", "create-store", "admin", "api", "order", "staff", "delivery", "distributor"]);

  const handleSlugChange = (v) => {
    setSlug(slugify(v));
    setStatus(null);
    setError("");
  };

  const handleCheck = async () => {
    if (!slug || slug === store.slug) return;
    if (RESERVED_SLUGS.has(slug)) { setStatus("taken"); return; }
    setStatus("checking");
    try {
      const available = await checkSlugAvailable(slug);
      setStatus(available ? "available" : "taken");
    } catch {
      setStatus(null);
    }
  };

  const handleSave = async () => {
    setError("");
    if (slug === store.slug) { setError("Yeh already aapka current link hai."); return; }
    if (!slug.trim()) { setError("Link khali nahi ho sakta."); return; }
    if (RESERVED_SLUGS.has(slug)) { setError("Yeh link naam use nahi kar sakte, doosra try karein."); return; }
    if (!confirm(`Pakka link badalna hai? Purana link "/${store.slug}" kaam karna band kar dega — agar customers ne woh save/bookmark kiya hai, unhe naya link dena hoga.`)) return;
    setSaving(true);
    try {
      const available = await checkSlugAvailable(slug);
      if (!available) { setStatus("taken"); setError("Yeh link naam already liya hua hai."); setSaving(false); return; }
      await updateStoreSlug(store.id, slug);
      setSuccess(true);
      setEditing(false);
      onRefresh();
      setTimeout(() => setSuccess(false), 3000);
    } catch (e) {
      setError(friendlyError(e) || "Link badalte waqt error aaya.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div style={{ background: "white", border: "1px solid #E3DECF", borderRadius: "12px", padding: "18px" }}>
      <div style={{ fontWeight: 700, fontSize: "13.5px", marginBottom: "4px" }}>🔗 Dukaan ka Link (URL)</div>
      <div style={{ fontSize: "11.5px", color: "#8B8576", marginBottom: "12px" }}>Abhi ka link: <b>dukaan-order-system.vercel.app/{store.slug}</b></div>

      {!editing ? (
        <button onClick={() => setEditing(true)} style={{ background: "white", border: "1px solid #1B4332", color: "#1B4332", borderRadius: "8px", padding: "8px 14px", fontSize: "12px", fontWeight: 700, cursor: "pointer" }}>
          Link Badlein
        </button>
      ) : (
        <>
          <div style={{ background: "#FDECEA", borderRadius: "8px", padding: "9px 11px", marginBottom: "10px", display: "flex", gap: "7px", alignItems: "flex-start" }}>
            <AlertCircle size={14} color="#B3261E" style={{ flexShrink: 0, marginTop: "1px" }} />
            <span style={{ fontSize: "11px", color: "#B3261E", lineHeight: 1.5 }}>Purana link (<b>/{store.slug}</b>) badalne ke baad kaam nahi karega. Agar customers ne yeh link save/bookmark kiya hai, unhe naya link dobara bhejna hoga.</span>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: "0", marginBottom: "6px" }}>
            <span style={{ fontSize: "12.5px", color: "#8B8576", background: "#F7F5F0", border: "1px solid #E3DECF", borderRight: "none", borderRadius: "8px 0 0 8px", padding: "9px 10px" }}>.../</span>
            <input
              value={slug}
              onChange={(e) => handleSlugChange(e.target.value)}
              onBlur={handleCheck}
              style={{ flex: 1, border: "1px solid #E3DECF", borderRadius: "0 8px 8px 0", padding: "9px 10px", fontSize: "13px", outline: "none" }}
            />
          </div>
          {status === "checking" && <div style={{ fontSize: "11px", color: "#8B8576" }}>Check ho raha hai...</div>}
          {status === "available" && <div style={{ fontSize: "11px", color: "#1B4332", fontWeight: 600 }}>✓ Yeh link available hai</div>}
          {status === "taken" && <div style={{ fontSize: "11px", color: "#B3261E", fontWeight: 600 }}>✗ Yeh link already liya hua hai ya reserved hai</div>}
          {error && <div style={{ fontSize: "11px", color: "#B3261E", marginTop: "4px" }}>{error}</div>}
          <div style={{ display: "flex", gap: "8px", marginTop: "10px" }}>
            <button onClick={() => { setEditing(false); setSlug(store.slug); setError(""); setStatus(null); }} style={{ flex: 1, background: "#F7F5F0", border: "1px solid #E3DECF", borderRadius: "8px", padding: "9px 0", fontSize: "12px", fontWeight: 700, color: "#5C5747", cursor: "pointer" }}>Cancel</button>
            <button onClick={handleSave} disabled={saving || status === "taken"} className="ddemo-btn" style={{ flex: 1, background: status === "taken" ? "#D8D2BF" : "#B3261E", color: "white", border: "none", borderRadius: "8px", padding: "9px 0", fontSize: "12px", fontWeight: 700, cursor: status === "taken" ? "not-allowed" : "pointer" }}>
              {saving ? "Save ho raha hai..." : "Haan, Link Badal Dein"}
            </button>
          </div>
        </>
      )}
      {success && <div style={{ marginTop: "10px", fontSize: "11.5px", color: "#1B4332", fontWeight: 600 }}>✓ Link safaltapoorvak badal diya gaya.</div>}
    </div>
  );
}

function StorageUsageBar({ usedBytes, limitBytes }) {
  const used = usedBytes || 0;
  const limit = limitBytes || 5 * 1024 * 1024 * 1024;
  const pct = Math.min(100, (used / limit) * 100);
  const usedGB = (used / (1024 * 1024 * 1024)).toFixed(2);
  const limitGB = (limit / (1024 * 1024 * 1024)).toFixed(0);
  const isNearFull = pct >= 85;

  return (
    <div style={{ background: "#F7F5F0", borderRadius: "10px", padding: "12px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "6px" }}>
        <div style={{ fontSize: "11.5px", fontWeight: 600, color: "#5C5747" }}>Photo Storage</div>
        <div style={{ fontSize: "11px", fontWeight: 700, color: isNearFull ? "#B3261E" : "#5C5747" }}>{usedGB} GB / {limitGB} GB</div>
      </div>
      <div style={{ height: 7, borderRadius: "999px", background: "#E3DECF", overflow: "hidden" }}>
        <div style={{ height: "100%", width: `${pct}%`, borderRadius: "999px", background: isNearFull ? "#B3261E" : "#1B4332", transition: "width 0.3s ease" }} />
      </div>
      {isNearFull && (
        <div style={{ fontSize: "10.5px", color: "#B3261E", marginTop: "6px" }}>
          Storage khatam hone wala hai — purani photos hatayein ya zyada space ke liye sampark karein.
        </div>
      )}
    </div>
  );
}

function StoreLogoPicker({ currentLogo, storeId, onChange }) {
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef(null);

  const handleUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 12 * 1024 * 1024) { alert("Logo 12MB se chhota hona chahiye."); return; }
    setUploading(true);
    try {
      const url = await uploadProductImage(file, storeId);
      onChange(url);
    } catch (err) {
      alert("Upload nahi ho paaya: " + friendlyError(err));
    } finally {
      setUploading(false);
    }
  };

  return (
    <div style={{ display: "flex", alignItems: "center", gap: "12px", background: "#F7F5F0", borderRadius: "10px", padding: "12px" }}>
      <div style={{ width: 52, height: 52, borderRadius: "10px", background: currentLogo ? "white" : "#D4A24C", border: "1px solid #E3DECF", display: "flex", alignItems: "center", justifyContent: "center", overflow: "hidden", flexShrink: 0 }}>
        {currentLogo ? <img src={currentLogo} alt="Dukaan Logo" style={{ width: "100%", height: "100%", objectFit: "cover" }} /> : <Store size={22} color="#123026" />}
      </div>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: "11.5px", fontWeight: 600, color: "#5C5747", marginBottom: "4px" }}>Dukaan ka Logo</div>
        <div style={{ display: "flex", gap: "8px" }}>
          <button onClick={() => fileRef.current?.click()} disabled={uploading} className="ddemo-btn" style={{ fontSize: "11.5px", fontWeight: 700, border: "1px solid #1B4332", color: "#1B4332", background: "white", borderRadius: "7px", padding: "6px 10px", cursor: "pointer" }}>
            {uploading ? "Upload ho raha hai..." : currentLogo ? "Logo Badlein" : "Logo Upload Karein"}
          </button>
          {currentLogo && (
            <button onClick={() => onChange("")} className="ddemo-btn" style={{ fontSize: "11.5px", fontWeight: 700, border: "1px solid #E3DECF", color: "#B3261E", background: "white", borderRadius: "7px", padding: "6px 10px", cursor: "pointer" }}>
              Hatayein
            </button>
          )}
        </div>
        <input ref={fileRef} type="file" accept="image/jpeg,image/png,image/webp" onChange={handleUpload} style={{ display: "none" }} />
      </div>
    </div>
  );
}

// ============================================================
// PRODUCT MANAGER
// ============================================================
function ProductManager({ store, products, onRefresh }) {
  const [adding, setAdding] = useState(false);
  const [expandedId, setExpandedId] = useState(null);
  const [reordering, setReordering] = useState(false);
  const [showCsvUpload, setShowCsvUpload] = useState(false);
  const [showCatalog, setShowCatalog] = useState(false);
  const [catalogCount, setCatalogCount] = useState(0);
  // Super Admin ne jin catalog products ko deactivate kiya, unke shop products yahan warning ke saath dikhte hain.
  const [catalogGone, setCatalogGone] = useState({});
  useEffect(() => {
    fetchCatalogLinkStatus(store.id).then(setCatalogGone).catch(() => setCatalogGone({}));
  }, [store.id, products.length]);
  // Central Catalog sirf un business types ke liye dikhta hai jinke liye catalog bana hai
  // (Cosmetics, Gift/Toys). Purane types mein count 0 -> button hi nahi dikhta.
  useEffect(() => {
    fetchCatalogProducts(store.business_type).then((r) => setCatalogCount(r.length)).catch(() => setCatalogCount(0));
  }, [store.business_type]);

  // Do products ke sort_order swap karke unka display sequence badalta hai
  // (list already sort_order se sorted aati hai fetchProducts() se).
  const moveProduct = async (index, direction) => {
    const targetIndex = index + direction;
    if (targetIndex < 0 || targetIndex >= products.length) return;
    const a = products[index], b = products[targetIndex];
    const aOrder = a.sort_order ?? index;
    const bOrder = b.sort_order ?? targetIndex;
    setReordering(true);
    try {
      // Agar dono ka sort_order kisi wajah se same hai (purane data mein
      // aisa ho sakta hai), to unka index hi use kar lete hain taaki
      // order badal jaaye.
      const newAOrder = aOrder === bOrder ? targetIndex : bOrder;
      const newBOrder = aOrder === bOrder ? index : aOrder;
      await Promise.all([
        updateProductOrder(a.id, newAOrder),
        updateProductOrder(b.id, newBOrder),
      ]);
      onRefresh();
    } catch (e) {
      alert("Order badalte waqt error aaya: " + friendlyError(e));
    } finally {
      setReordering(false);
    }
  };

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "12px", flexWrap: "wrap", gap: "8px" }}>
        <div style={{ fontSize: "12px", color: "#8B8576" }}>{products.length} products · ⭐ ya ↑↓ se apni dukaan saja sakte hain</div>
        <div style={{ display: "flex", gap: "6px" }}>
          <button onClick={() => setShowCsvUpload(true)} className="ddemo-btn" style={{ display: "flex", alignItems: "center", gap: "5px", background: "white", border: "1px solid #1B4332", color: "#1B4332", borderRadius: "8px", padding: "8px 11px", fontSize: "12px", fontWeight: 700, cursor: "pointer" }}>
            <FileSpreadsheet size={13} /> Bulk Upload
          </button>
          <button onClick={() => (catalogCount > 0 ? setShowCatalog(true) : setAdding(true))} className="ddemo-btn" style={{ display: "flex", alignItems: "center", gap: "6px", background: "#1B4332", color: "white", border: "none", borderRadius: "8px", padding: "8px 14px", fontSize: "12.5px", fontWeight: 700, cursor: "pointer" }}>
            <Plus size={14} /> Add Product
          </button>
        </div>
      </div>

      {adding && (
        <NewProductForm
          storeId={store.id}
          businessType={store.business_type}
          onCancel={() => setAdding(false)}
          onSave={async (form) => {
            await createProduct(store.id, { ...form, sort_order: products.length + 1 });
            setAdding(false);
            onRefresh();
          }}
        />
      )}

      {showCatalog && (
        <CatalogPicker
          store={store}
          products={products}
          onClose={() => setShowCatalog(false)}
          onCustom={() => { setShowCatalog(false); setAdding(true); }}
          onAdded={() => { setShowCatalog(false); onRefresh(); }}
        />
      )}

      {showCsvUpload && (
        <CsvBulkUploadModal
          store={store}
          onClose={() => setShowCsvUpload(false)}
          onDone={() => { setShowCsvUpload(false); onRefresh(); }}
        />
      )}

      <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
        {products.map((p, idx) => (
          <ProductRow
            key={p.id}
            product={p}
            storeId={store.id}
            businessType={store.business_type}
            gstEnabled={store.gst_enabled}
            expanded={expandedId === p.id}
            onToggle={() => setExpandedId(expandedId === p.id ? null : p.id)}
            onRefresh={onRefresh}
            onMoveUp={idx > 0 ? () => moveProduct(idx, -1) : null}
            onMoveDown={idx < products.length - 1 ? () => moveProduct(idx, 1) : null}
            reordering={reordering}
            catalogGone={!!catalogGone[p.id]}
          />
        ))}
      </div>
    </div>
  );
}

// ============================================================
// IMAGE PICKER — Photo Upload (sirf apni photo, "Ready Icons" hata diya
// gaya — isse products asli/professional dikhte hain, aur galat business
// type ki icons dikhne ka confusion bhi khatam ho jaata hai)
// ============================================================
function ImagePicker({ currentImage, storeId, onChange }) {
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef(null);

  const handleUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 12 * 1024 * 1024) { alert("Photo 12MB se chhoti honi chahiye."); return; }
    setUploading(true);
    try {
      const url = await uploadProductImage(file, storeId);
      onChange(url);
    } catch (err) {
      alert(friendlyError(err) || "Upload nahi ho paaya.");
    } finally {
      setUploading(false);
    }
  };

  return (
    <div style={{ background: "#F7F5F0", borderRadius: "10px", padding: "12px" }}>
      <div style={{ fontSize: "11.5px", fontWeight: 600, color: "#5C5747", marginBottom: "8px" }}>Product ki Photo</div>
      <input ref={fileRef} type="file" accept="image/jpeg,image/png,image/webp" onChange={handleUpload} style={{ display: "none" }} />
      {currentImage ? (
        <div style={{ display: "flex", alignItems: "center", gap: "10px", padding: "10px", background: "white", borderRadius: "9px", border: "1px solid #E3DECF" }}>
          <img src={currentImage} alt="product" style={{ width: 48, height: 48, objectFit: "cover", borderRadius: "7px" }} />
          <div style={{ flex: 1, fontSize: "11.5px", color: "#5C5747" }}>Photo upload ho gayi ✅</div>
          <button onClick={() => onChange(null)} style={{ border: "none", background: "transparent", color: "#B3261E", cursor: "pointer", fontSize: "11px", fontWeight: 600 }}>Hatao</button>
        </div>
      ) : (
        <button
          onClick={() => fileRef.current?.click()}
          disabled={uploading}
          style={{ width: "100%", padding: "20px 0", border: "2px dashed #D4A24C", borderRadius: "9px", background: "white", cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", gap: "6px" }}
        >
          <Upload size={20} color="#D4A24C" />
          <span style={{ fontSize: "12px", fontWeight: 600, color: "#5C5747" }}>{uploading ? "Upload ho raha hai..." : "Photo chunein (Max 12MB — apne aap chhoti ho jayegi)"}</span>
          <span style={{ fontSize: "10.5px", color: "#8B8576" }}>JPG, PNG, WebP</span>
        </button>
      )}
    </div>
  );
}

// ============================================================
// NEW PRODUCT FORM
// ============================================================
function NewProductForm({ storeId, businessType, onCancel, onSave, prefillBarcode }) {
  const [name, setName] = useState("");
  const [category, setCategory] = useState("");
  const [description, setDescription] = useState("");
  const [emoji, setEmoji] = useState("📦");
  const [imageUrl, setImageUrl] = useState(null);
  const [images, setImages] = useState([]);
  const [subCategory, setSubCategory] = useState("");
  const [brand, setBrand] = useState("");
  const [ageGroup, setAgeGroup] = useState("");
  const [hasPresets, setHasPresets] = useState(false);
  const [saving, setSaving] = useState(false);
  const valid = name.trim() && category.trim();
  const isGallery = getShoppingMode(businessType) === "gallery";

  const handleSave = async () => {
    setSaving(true);
    await onSave({
      name, category, emoji, description, image_url: isGallery ? undefined : imageUrl, image_urls: isGallery ? images : undefined,
      ...(hasPresets ? { brand, sub_category: subCategory, age_group: ageGroup } : {}),
    });
    setSaving(false);
  };

  return (
    <div style={{ background: "#F7F5F0", border: "1px solid #E3DECF", borderRadius: "12px", padding: "14px", marginBottom: "12px" }}>
      <div style={{ fontWeight: 700, fontSize: "13px", marginBottom: "10px" }}>Naya Product</div>
      {prefillBarcode && (
        <div style={{ fontSize: "11px", color: "#1B4332", fontWeight: 600, marginBottom: "10px", background: "#E7F0EA", padding: "8px 10px", borderRadius: "7px" }}>
          🔍 Barcode <b>{prefillBarcode}</b> kisi existing product se match nahi hua. Naam/category bharein — save karte hi is barcode ke saath ek variant bhi turant add karne ka option milega.
        </div>
      )}
      {isGallery
        ? <MultiImagePicker images={images} storeId={storeId} onChange={setImages} />
        : <ImagePicker currentImage={imageUrl} storeId={storeId} onChange={setImageUrl} />
      }
      <div style={{ display: "flex", flexDirection: "column", gap: "8px", marginTop: "10px" }}>
        <Field label="Product ka Naam" value={name} onChange={setName} placeholder="jaise Chini (Sugar)" />
        <CategoryFields
          businessType={businessType}
          category={category} setCategory={setCategory}
          subCategory={subCategory} setSubCategory={setSubCategory}
          brand={brand} setBrand={setBrand}
          ageGroup={ageGroup} setAgeGroup={setAgeGroup}
          onActive={setHasPresets}
          fallback={<Field label="Category" value={category} onChange={setCategory} placeholder="jaise Staples, Hardware, Medical" />}
        />
        <Field label="Description (optional)" value={description} onChange={setDescription} placeholder={isGallery ? "jaise Cotton, Size M-XL available" : "koi khaas jaankari (optional)"} textarea />
      </div>
      <div style={{ display: "flex", gap: "8px", marginTop: "12px" }}>
        <button onClick={onCancel} style={{ flex: 1, background: "white", border: "1px solid #E3DECF", borderRadius: "8px", padding: "9px 0", fontSize: "12.5px", fontWeight: 700, color: "#5C5747", cursor: "pointer" }}>Cancel</button>
        <button
          disabled={!valid || saving}
          onClick={handleSave}
          className="ddemo-btn"
          style={{ flex: 1, background: valid ? "#1B4332" : "#D8D2BF", color: "white", border: "none", borderRadius: "8px", padding: "9px 0", fontSize: "12.5px", fontWeight: 700, cursor: valid ? "pointer" : "not-allowed" }}
        >
          {saving ? "Add ho raha hai..." : "Add Karein"}
        </button>
      </div>
    </div>
  );
}

function MultiImagePicker({ images, storeId, onChange }) {
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef(null);
  const MAX_PHOTOS = 4;

  const handleUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (images.length >= MAX_PHOTOS) { alert(`Zyada se zyada ${MAX_PHOTOS} photos daal sakte hain.`); return; }
    if (file.size > 12 * 1024 * 1024) { alert("Photo 12MB se chhoti honi chahiye."); return; }
    setUploading(true);
    try {
      const url = await uploadProductImage(file, storeId);
      onChange([...images, url]);
    } catch (err) {
      alert(friendlyError(err) || "Upload nahi ho paaya.");
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  const removeAt = (idx) => onChange(images.filter((_, i) => i !== idx));

  return (
    <div style={{ background: "#F7F5F0", borderRadius: "10px", padding: "12px" }}>
      <div style={{ fontSize: "11.5px", fontWeight: 600, color: "#5C5747", marginBottom: "8px" }}>
        Product ki Photos ({images.length}/{MAX_PHOTOS}) — pehli photo customer ko sabse pehle dikhegi
      </div>
      <div style={{ display: "flex", gap: "10px", flexWrap: "wrap" }}>
        {images.map((url, idx) => (
          <div key={idx} style={{ position: "relative", width: 64, height: 64 }}>
            <img src={url} alt={`photo-${idx}`} style={{ width: "100%", height: "100%", objectFit: "cover", borderRadius: "8px", border: idx === 0 ? "2px solid #D4A24C" : "1px solid #E3DECF" }} />
            <button onClick={() => removeAt(idx)} style={{ position: "absolute", top: -6, right: -6, width: 20, height: 20, borderRadius: "50%", background: "#B3261E", color: "white", border: "2px solid white", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", padding: 0 }}>
              <X size={11} />
            </button>
          </div>
        ))}
        {images.length < MAX_PHOTOS && (
          <button onClick={() => fileRef.current?.click()} disabled={uploading} style={{ width: 64, height: 64, borderRadius: "8px", border: "2px dashed #D4A24C", background: "white", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <Plus size={20} color="#D4A24C" />
          </button>
        )}
      </div>
      {uploading && <div style={{ fontSize: "10.5px", color: "#8B8576", marginTop: "6px" }}>Upload ho raha hai...</div>}
      <input ref={fileRef} type="file" accept="image/jpeg,image/png,image/webp" onChange={handleUpload} style={{ display: "none" }} />
    </div>
  );
}

// ============================================================
// PRODUCT ROW
// ============================================================
function ProductRow({ product, storeId, businessType, gstEnabled, expanded, onToggle, onRefresh, onMoveUp, onMoveDown, reordering, catalogGone }) {
  const [editing, setEditing] = useState(false);
  const [addingVariant, setAddingVariant] = useState(false);
  const [togglingFeatured, setTogglingFeatured] = useState(false);
  const [togglingAvail, setTogglingAvail] = useState(false);
  const isAvailable = product.is_available !== false;

  const handleDeleteProduct = async () => {
    if (!confirm(`"${product.name}" ko delete karein?`)) return;
    try { await deleteProduct(product.id); onRefresh(); }
    catch (e) { alert("Delete nahi ho paaya: " + friendlyError(e)); }
  };

  const handleToggleFeatured = async (e) => {
    e.stopPropagation();
    setTogglingFeatured(true);
    try { await updateProductFeatured(product.id, !product.featured); onRefresh(); }
    catch (err) { alert("Featured toggle nahi ho paaya: " + friendlyError(err)); }
    finally { setTogglingFeatured(false); }
  };

  const handleToggleAvailable = async (e) => {
    e.stopPropagation();
    setTogglingAvail(true);
    try { await updateProductAvailability(product.id, !isAvailable); onRefresh(); }
    catch (err) { alert("Availability badal nahi payi: " + friendlyError(err)); }
    finally { setTogglingAvail(false); }
  };

  // Display: photo > emoji
  const displayImage = product.image_url || null;
  const displayEmoji = product.emoji || "📦";

  return (
    <div style={{ background: "white", border: product.featured ? "1.5px solid #D4A24C" : "1px solid #E3DECF", borderRadius: "12px", overflow: "hidden" }}>
      <div style={{ display: "flex", alignItems: "center", gap: "10px", padding: "12px 13px", cursor: "pointer" }} onClick={onToggle}>
        {/* Reorder arrows — dukaandar apni marzi se products upar-neeche kar sakta hai */}
        <div style={{ display: "flex", flexDirection: "column", gap: "1px", flexShrink: 0 }} onClick={(e) => e.stopPropagation()}>
          <button onClick={onMoveUp} disabled={!onMoveUp || reordering} style={{ ...arrowBtnStyle, opacity: onMoveUp ? 1 : 0.25 }}><ArrowUp size={12} /></button>
          <button onClick={onMoveDown} disabled={!onMoveDown || reordering} style={{ ...arrowBtnStyle, opacity: onMoveDown ? 1 : 0.25 }}><ArrowDown size={12} /></button>
        </div>
        {displayImage
          ? <img src={displayImage} alt={product.name} style={{ width: 36, height: 36, objectFit: "cover", borderRadius: "7px", flexShrink: 0 }} />
          : <span style={{ fontSize: "22px", flexShrink: 0 }}>{displayEmoji}</span>
        }
        <div style={{ flex: 1 }}>
          <div style={{ fontWeight: 700, fontSize: "13px" }}>{product.name}</div>
          <div style={{ fontSize: "10.5px", color: "#8B8576" }}>{product.category} · {product.variants.length} variant{product.variants.length !== 1 ? "s" : ""}{!isAvailable && <span style={{ color: "#B3261E", fontWeight: 700 }}> · Unavailable</span>}</div>
          {catalogGone && (
            <div style={{ fontSize: "10.5px", color: "#9A6B00", fontWeight: 600, marginTop: "2px" }}>⚠ Yeh product Central Catalog se hata diya gaya hai — aapka product safe hai aur chalta rahega</div>
          )}
        </div>
        <button onClick={handleToggleAvailable} disabled={togglingAvail} title={isAvailable ? "Available hai — dabane par unavailable" : "Unavailable hai — dabane par available"} style={{ ...iconBtnStyle, color: isAvailable ? "#1B4332" : "#B3261E" }}>
          {isAvailable ? <Eye size={15} /> : <EyeOff size={15} />}
        </button>
        <button onClick={handleToggleFeatured} disabled={togglingFeatured} title="Customer ko badi photo ke saath dikhayein" style={{ ...iconBtnStyle, color: product.featured ? "#D4A24C" : "#B7AF9B" }}>
          <Star size={15} fill={product.featured ? "#D4A24C" : "none"} />
        </button>
        <button onClick={(e) => { e.stopPropagation(); setEditing(!editing); }} style={iconBtnStyle}><Edit2 size={14} /></button>
        <button onClick={(e) => { e.stopPropagation(); handleDeleteProduct(); }} style={{ ...iconBtnStyle, color: "#B3261E" }}><Trash2 size={14} /></button>
        {expanded ? <ChevronUp size={16} color="#8B8576" /> : <ChevronDown size={16} color="#8B8576" />}
      </div>

      {editing && (
        <EditProductForm
          product={product}
          storeId={storeId}
          businessType={businessType}
          onCancel={() => setEditing(false)}
          onSave={async (form) => { await updateProduct(product.id, form); setEditing(false); onRefresh(); }}
        />
      )}

      {expanded && (
        <div style={{ borderTop: "1px solid #E3DECF", padding: "12px 13px", background: "#FBFAF6" }}>
          {product.variants.map((v) => (
            <VariantRow key={v.id} variant={v} businessType={businessType} gstEnabled={gstEnabled} onRefresh={onRefresh} />
          ))}
          {addingVariant ? (
            <NewVariantForm
              businessType={businessType}
              gstEnabled={gstEnabled}
              onCancel={() => setAddingVariant(false)}
              onSave={async (form) => { await createVariant(product.id, form); setAddingVariant(false); onRefresh(); }}
            />
          ) : (
            <button onClick={() => setAddingVariant(true)} className="ddemo-btn" style={{ display: "flex", alignItems: "center", gap: "6px", background: "white", border: "1px dashed #1B4332", color: "#1B4332", borderRadius: "8px", padding: "8px 12px", fontSize: "12px", fontWeight: 700, cursor: "pointer", marginTop: "6px" }}>
              <Plus size={13} /> Naya Variant/Brand Add Karein
            </button>
          )}
        </div>
      )}
    </div>
  );
}

function EditProductForm({ product, storeId, businessType, onCancel, onSave }) {
  const [name, setName] = useState(product.name);
  const [category, setCategory] = useState(product.category);
  const [description, setDescription] = useState(product.description || "");
  const [emoji, setEmoji] = useState(product.emoji || "📦");
  const [imageUrl, setImageUrl] = useState(product.image_url || null);
  const [images, setImages] = useState(product.image_urls && product.image_urls.length > 0 ? product.image_urls : (product.image_url ? [product.image_url] : []));
  const [subCategory, setSubCategory] = useState(product.sub_category || "");
  const [brand, setBrand] = useState(product.brand || "");
  const [ageGroup, setAgeGroup] = useState(product.age_group || "");
  const [hasPresets, setHasPresets] = useState(false);
  const [saving, setSaving] = useState(false);
  const isGallery = getShoppingMode(businessType) === "gallery";

  const handleSave = async () => {
    setSaving(true);
    await onSave({
      name, category, emoji, description, image_url: isGallery ? undefined : imageUrl, image_urls: isGallery ? images : undefined,
      ...(hasPresets ? { brand, sub_category: subCategory, age_group: ageGroup } : {}),
    });
    setSaving(false);
  };

  return (
    <div style={{ borderTop: "1px solid #E3DECF", padding: "12px 13px", background: "#F7F5F0" }}>
      {isGallery
        ? <MultiImagePicker images={images} storeId={storeId} onChange={setImages} />
        : <ImagePicker currentImage={imageUrl} storeId={storeId} onChange={setImageUrl} />
      }
      <div style={{ display: "flex", flexDirection: "column", gap: "8px", marginTop: "10px" }}>
        <Field label="Product ka Naam" value={name} onChange={setName} />
        <CategoryFields
          businessType={businessType}
          category={category} setCategory={setCategory}
          subCategory={subCategory} setSubCategory={setSubCategory}
          brand={brand} setBrand={setBrand}
          ageGroup={ageGroup} setAgeGroup={setAgeGroup}
          onActive={setHasPresets}
          fallback={<Field label="Category" value={category} onChange={setCategory} />}
        />
        <Field label="Description (optional)" value={description} onChange={setDescription} textarea />
      </div>
      <div style={{ display: "flex", gap: "8px", marginTop: "10px" }}>
        <button onClick={onCancel} style={{ flex: 1, background: "white", border: "1px solid #E3DECF", borderRadius: "8px", padding: "9px 0", fontSize: "12.5px", fontWeight: 700, color: "#5C5747", cursor: "pointer" }}>Cancel</button>
        <button disabled={saving} onClick={handleSave} className="ddemo-btn" style={{ flex: 1, background: "#1B4332", color: "white", border: "none", borderRadius: "8px", padding: "9px 0", fontSize: "12.5px", fontWeight: 700, cursor: "pointer" }}>
          {saving ? "Save ho raha hai..." : "Save Karein"}
        </button>
      </div>
    </div>
  );
}

// ============================================================
// VARIANT MANAGEMENT
// ============================================================
function VariantRow({ variant, businessType, gstEnabled, onRefresh }) {
  const [editing, setEditing] = useState(false);

  const handleDelete = async () => {
    if (!confirm(`"${variant.label}" variant delete karein?`)) return;
    try { await deleteVariant(variant.id); onRefresh(); }
    catch (e) { alert("Delete nahi ho paaya: " + friendlyError(e)); }
  };

  if (editing) {
    return (
      <EditVariantForm
        variant={variant}
        businessType={businessType}
        gstEnabled={gstEnabled}
        onCancel={() => setEditing(false)}
        onSave={async (form) => { await updateVariant(variant.id, form); setEditing(false); onRefresh(); }}
      />
    );
  }

  const discount = getDiscountInfo(variant.mrp, variant.price);

  return (
    <div style={{ display: "flex", alignItems: "center", gap: "10px", padding: "8px 0", borderBottom: "1px solid #E3DECF" }}>
      <div style={{ flex: 1 }}>
        <div style={{ fontWeight: 600, fontSize: "12.5px" }}>{variant.label}</div>
        <div style={{ fontSize: "10.5px", color: "#8B8576" }}>
          {discount ? <><s>₹{discount.mrp}</s> ₹{discount.price} <span style={{ color: "#1B4332", fontWeight: 700 }}>({discount.pct}% OFF)</span></> : `₹${variant.price}`} / {variant.unit} · Stock: {variant.stock}
        </div>
      </div>
      <button onClick={() => setEditing(true)} style={iconBtnStyle}><Edit2 size={13} /></button>
      <button onClick={handleDelete} style={{ ...iconBtnStyle, color: "#B3261E" }}><Trash2 size={13} /></button>
    </div>
  );
}

// datetime-local input browser ke local timezone mein kaam karta hai
// (YYYY-MM-DDTHH:mm), lekin DB mein UTC timestamptz store hota hai —
// yeh 2 helpers dono ke beech convert karte hain.
function toDatetimeLocal(isoString) {
  if (!isoString) return "";
  const d = new Date(isoString);
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
function fromDatetimeLocal(localStr) {
  return localStr ? new Date(localStr).toISOString() : null;
}

function EditVariantForm({ variant, businessType, gstEnabled, onCancel, onSave }) {
  const [label, setLabel] = useState(variant.label);
  const [unit, setUnit] = useState(variant.unit);
  const [price, setPrice] = useState(String(variant.price));
  const [mrp, setMrp] = useState(variant.mrp != null ? String(variant.mrp) : "");
  const [stock, setStock] = useState(String(variant.stock));
  const [gstRate, setGstRate] = useState(String(variant.gst_rate ?? 0));
  const [barcode, setBarcode] = useState(variant.barcode || "");
  const [offerEnabled, setOfferEnabled] = useState(variant.offer_enabled || false);
  const [offerPrice, setOfferPrice] = useState(variant.offer_price != null ? String(variant.offer_price) : "");
  const [offerStart, setOfferStart] = useState(toDatetimeLocal(variant.offer_starts_at));
  const [offerEnd, setOfferEnd] = useState(toDatetimeLocal(variant.offer_ends_at));
  const [qtyTiers, setQtyTiers] = useState(
    Array.isArray(variant.qty_deal_tiers) ? variant.qty_deal_tiers.map((t) => ({ qty: String(t.qty), price: String(t.price) })) : []
  );
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState("");
  const discount = getDiscountInfo(mrp, price);

  const handleSave = async () => {
    setFormError("");
    const priceNum = Number(price);
    const stockNum = Number(stock);
    const mrpNum = mrp.trim() === "" ? null : Number(mrp);
    const offerPriceNum = offerPrice.trim() === "" ? null : Number(offerPrice);
    if (!label.trim() || !unit.trim()) { setFormError("Naam aur Unit khaali nahi ho sakte."); return; }
    if (price === "" || isNaN(priceNum) || priceNum <= 0) { setFormError("Price ek valid number hona chahiye, 0 se zyada."); return; }
    if (mrpNum !== null && (isNaN(mrpNum) || mrpNum <= 0)) { setFormError("MRP ek valid number hona chahiye, 0 se zyada."); return; }
    if (stock === "" || isNaN(stockNum) || stockNum < 0) { setFormError("Stock ek valid number hona chahiye (0 ya usse zyada)."); return; }
    if (offerEnabled) {
      if (offerPriceNum === null || isNaN(offerPriceNum) || offerPriceNum <= 0) { setFormError("Offer Price daalein, 0 se zyada."); return; }
      if (offerPriceNum >= priceNum) { setFormError("Offer Price normal Selling Price se kam hona chahiye."); return; }
      if (!offerStart || !offerEnd) { setFormError("Offer ki Start aur End date/time dono daalein."); return; }
      if (new Date(offerEnd) <= new Date(offerStart)) { setFormError("Offer End time, Start time se baad ka hona chahiye."); return; }
    }
    let cleanTiers = [];
    if (qtyTiers.length > 0) {
      for (const t of qtyTiers) {
        const q = Number(t.qty), p = Number(t.price);
        if (!t.qty || !t.price || isNaN(q) || isNaN(p) || q <= 0 || p <= 0) { setFormError("Buy More Save More ke sab tiers mein valid Qty aur Price bharein."); return; }
        cleanTiers.push({ qty: q, price: p });
      }
      cleanTiers.sort((a, b) => a.qty - b.qty);
      for (let i = 1; i < cleanTiers.length; i++) {
        if (cleanTiers[i].qty === cleanTiers[i - 1].qty) { setFormError("Do tiers ka Qty same nahi ho sakta."); return; }
      }
    }
    setSaving(true);
    await onSave({
      label, unit, price: priceNum, mrp: mrpNum, stock: stockNum, barcode: barcode.trim() || null,
      offer_enabled: offerEnabled, offer_price: offerEnabled ? offerPriceNum : null,
      offer_starts_at: offerEnabled ? fromDatetimeLocal(offerStart) : null,
      offer_ends_at: offerEnabled ? fromDatetimeLocal(offerEnd) : null,
      qty_deal_tiers: cleanTiers,
      gst_rate: Number(gstRate) || 0,
    });
    setSaving(false);
  };

  return (
    <div style={{ background: "white", border: "1px solid #E3DECF", borderRadius: "8px", padding: "10px", margin: "6px 0" }}>
      <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
        <Field label="Naam/Brand" value={label} onChange={setLabel} />
        <div style={{ display: "flex", gap: "6px" }}>
          <div style={{ flex: 1 }}><UnitField businessType={businessType} value={unit} onChange={setUnit} /></div>
          <div style={{ flex: 1 }}><Field label="MRP (₹, optional)" value={mrp} onChange={(v) => setMrp(v.replace(/[^\d.]/g, ""))} placeholder="jaise 100" /></div>
          <div style={{ flex: 1 }}><Field label="Selling Price (₹)" value={price} onChange={(v) => setPrice(v.replace(/[^\d.]/g, ""))} /></div>
          <div style={{ flex: 1 }}><Field label="Stock" value={stock} onChange={(v) => setStock(v.replace(/\D/g, ""))} /></div>
        </div>
        {discount && (
          <div style={{ fontSize: "11px", color: "#1B4332", fontWeight: 700, background: "#E7F0EA", borderRadius: "6px", padding: "5px 9px" }}>
            Customer ko dikhega: <s style={{ color: "#8B8576" }}>₹{discount.mrp}</s> ₹{discount.price} — {discount.pct}% OFF
          </div>
        )}
        {gstEnabled && <GstRateField value={gstRate} onChange={setGstRate} />}
        <Field label="Barcode (optional)" value={barcode} onChange={setBarcode} placeholder="jaise 8901234567890" />
        <LimitedTimeDealFields
          enabled={offerEnabled} onEnabledChange={setOfferEnabled}
          offerPrice={offerPrice} onOfferPriceChange={setOfferPrice}
          start={offerStart} onStartChange={setOfferStart}
          end={offerEnd} onEndChange={setOfferEnd}
          basePrice={price}
        />
        <QuantityDealFields tiers={qtyTiers} onChange={setQtyTiers} basePrice={price} />
      </div>
      {formError && <div style={{ color: "#B3261E", fontSize: "11px", marginTop: "6px" }}>{formError}</div>}
      <div style={{ display: "flex", gap: "8px", marginTop: "8px" }}>
        <button onClick={onCancel} style={{ flex: 1, background: "#F7F5F0", border: "1px solid #E3DECF", borderRadius: "7px", padding: "7px 0", fontSize: "11.5px", fontWeight: 700, color: "#5C5747", cursor: "pointer" }}>Cancel</button>
        <button disabled={saving} onClick={handleSave} className="ddemo-btn" style={{ flex: 1, background: "#1B4332", color: "white", border: "none", borderRadius: "7px", padding: "7px 0", fontSize: "11.5px", fontWeight: 700, cursor: "pointer" }}>
          {saving ? "..." : "Save"}
        </button>
      </div>
    </div>
  );
}

// Shared Limited-Time Deal fields, dono NewVariantForm aur
// EditVariantForm mein use hote hain.
function LimitedTimeDealFields({ enabled, onEnabledChange, offerPrice, onOfferPriceChange, start, onStartChange, end, onEndChange, basePrice }) {
  const pct = enabled && offerPrice && basePrice && Number(offerPrice) < Number(basePrice)
    ? Math.round(((Number(basePrice) - Number(offerPrice)) / Number(basePrice)) * 100)
    : null;
  return (
    <div style={{ border: "1px solid #F3C6C1", background: "#FFF9F5", borderRadius: "8px", padding: "10px" }}>
      <label style={{ display: "flex", alignItems: "center", gap: "8px", cursor: "pointer" }}>
        <input type="checkbox" checked={enabled} onChange={(e) => onEnabledChange(e.target.checked)} style={{ width: 15, height: 15, cursor: "pointer" }} />
        <span style={{ fontSize: "12px", fontWeight: 700, color: "#B3261E" }}>🔥 Limited-Time Deal Lagayein</span>
      </label>
      {enabled && (
        <div style={{ display: "flex", flexDirection: "column", gap: "6px", marginTop: "8px" }}>
          <Field label="Offer Price (₹)" value={offerPrice} onChange={(v) => onOfferPriceChange(v.replace(/[^\d.]/g, ""))} placeholder="Normal price se kam" />
          <div style={{ display: "flex", gap: "6px" }}>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: "11px", fontWeight: 600, color: "#5C5747", marginBottom: "4px" }}>Shuru</div>
              <input type="datetime-local" value={start} onChange={(e) => onStartChange(e.target.value)} style={{ width: "100%", border: "1px solid #E3DECF", borderRadius: "7px", padding: "8px 8px", fontSize: "11.5px", fontFamily: "inherit", outline: "none" }} />
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: "11px", fontWeight: 600, color: "#5C5747", marginBottom: "4px" }}>Khatam</div>
              <input type="datetime-local" value={end} onChange={(e) => onEndChange(e.target.value)} style={{ width: "100%", border: "1px solid #E3DECF", borderRadius: "7px", padding: "8px 8px", fontSize: "11.5px", fontFamily: "inherit", outline: "none" }} />
            </div>
          </div>
          {pct && (
            <div style={{ fontSize: "11px", color: "#B3261E", fontWeight: 700 }}>🔥 Customer ko dikhega: <s style={{ color: "#8B8576" }}>₹{basePrice}</s> ₹{offerPrice} — {pct}% OFF (sirf tay kiye gaye time ke andar)</div>
          )}
          <div style={{ fontSize: "10px", color: "#8B8576" }}>Time khatam hote hi normal price apne aap wapas aa jaayega — kuch manually hataana nahi padega.</div>
        </div>
      )}
    </div>
  );
}

// ============================================================
// BUY MORE, SAVE MORE — quantity-based tiers (jaise "2 lo to ₹190,
// 3 lo to ₹270"). Chhota, repeatable list — max 4 tiers rakhte hain
// taaki UI simple rahe.
// ============================================================
function QuantityDealFields({ tiers, onChange, basePrice }) {
  const enabled = tiers.length > 0;

  const handleToggle = (checked) => {
    if (checked) onChange([{ qty: "2", price: "" }]);
    else onChange([]);
  };
  const updateTier = (idx, field, value) => {
    const copy = tiers.map((t, i) => (i === idx ? { ...t, [field]: value } : t));
    onChange(copy);
  };
  const addTier = () => {
    if (tiers.length >= 4) return;
    onChange([...tiers, { qty: "", price: "" }]);
  };
  const removeTier = (idx) => onChange(tiers.filter((_, i) => i !== idx));

  return (
    <div style={{ border: "1px solid #D4E4D9", background: "#F5FAF6", borderRadius: "8px", padding: "10px" }}>
      <label style={{ display: "flex", alignItems: "center", gap: "8px", cursor: "pointer" }}>
        <input type="checkbox" checked={enabled} onChange={(e) => handleToggle(e.target.checked)} style={{ width: 15, height: 15, cursor: "pointer" }} />
        <span style={{ fontSize: "12px", fontWeight: 700, color: "#1B4332" }}>📦 Buy More, Save More</span>
      </label>
      {enabled && (
        <div style={{ display: "flex", flexDirection: "column", gap: "6px", marginTop: "8px" }}>
          {tiers.map((t, idx) => (
            <div key={idx} style={{ display: "flex", alignItems: "center", gap: "6px" }}>
              <div style={{ flex: 1 }}>
                <input value={t.qty} onChange={(e) => updateTier(idx, "qty", e.target.value.replace(/\D/g, ""))} placeholder="Qty" style={{ width: "100%", border: "1px solid #E3DECF", borderRadius: "7px", padding: "7px 8px", fontSize: "12px", outline: "none", boxSizing: "border-box" }} />
              </div>
              <span style={{ fontSize: "11px", color: "#8B8576" }}>piece =</span>
              <div style={{ flex: 1 }}>
                <input value={t.price} onChange={(e) => updateTier(idx, "price", e.target.value.replace(/[^\d.]/g, ""))} placeholder="₹ Total" style={{ width: "100%", border: "1px solid #E3DECF", borderRadius: "7px", padding: "7px 8px", fontSize: "12px", outline: "none", boxSizing: "border-box" }} />
              </div>
              <button onClick={() => removeTier(idx)} style={{ border: "none", background: "transparent", cursor: "pointer", color: "#B3261E", padding: "4px" }}><Trash2 size={13} /></button>
            </div>
          ))}
          {tiers.length < 4 && (
            <button onClick={addTier} style={{ display: "flex", alignItems: "center", gap: "5px", background: "white", border: "1px dashed #1B4332", color: "#1B4332", borderRadius: "7px", padding: "6px 10px", fontSize: "11px", fontWeight: 700, cursor: "pointer", alignSelf: "flex-start" }}>
              <Plus size={11} /> Aur Tier Add Karein
            </button>
          )}
          <div style={{ fontSize: "10px", color: "#8B8576" }}>Jaise: 2 piece = ₹190 (matlab dono milakar ₹190, ₹95/piece ke hisaab se). Cart mein customer ki quantity ke hisaab se best deal automatically laagu hoga.</div>
        </div>
      )}
    </div>
  );
}

function NewVariantForm({ businessType, gstEnabled, onCancel, onSave, prefillBarcode }) {
  const [label, setLabel] = useState("");
  const [unit, setUnit] = useState(getUnitPresets(businessType)[0]);
  const [price, setPrice] = useState("");
  const [mrp, setMrp] = useState("");
  // Salon/Beauty Parlour ke "services" products jaise "khatam" nahi hote —
  // stock yahan sirf isliye hai kyunki DB structure products/variants ke
  // liye common hai. Booking hamesha available rahe isliye default bahut
  // zyada rakha (dukaandar ko is field ki chinta hi na karni pade).
  const [stock, setStock] = useState(businessType === "salon" ? "9999" : "0");
  const [gstRate, setGstRate] = useState("0");
  const [barcode, setBarcode] = useState(prefillBarcode || "");
  const [offerEnabled, setOfferEnabled] = useState(false);
  const [offerPrice, setOfferPrice] = useState("");
  const [offerStart, setOfferStart] = useState("");
  const [offerEnd, setOfferEnd] = useState("");
  const [qtyTiers, setQtyTiers] = useState([]);
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState("");
  const valid = label.trim() && unit.trim() && price;
  const discount = getDiscountInfo(mrp, price);

  const handleSave = async () => {
    setFormError("");
    const priceNum = Number(price);
    const stockNum = Number(stock);
    const mrpNum = mrp.trim() === "" ? null : Number(mrp);
    const offerPriceNum = offerPrice.trim() === "" ? null : Number(offerPrice);
    if (price === "" || isNaN(priceNum) || priceNum <= 0) { setFormError("Price ek valid number hona chahiye, 0 se zyada."); return; }
    if (mrpNum !== null && (isNaN(mrpNum) || mrpNum <= 0)) { setFormError("MRP ek valid number hona chahiye, 0 se zyada."); return; }
    if (stock !== "" && (isNaN(stockNum) || stockNum < 0)) { setFormError("Stock ek valid number hona chahiye (0 ya usse zyada)."); return; }
    if (offerEnabled) {
      if (offerPriceNum === null || isNaN(offerPriceNum) || offerPriceNum <= 0) { setFormError("Offer Price daalein, 0 se zyada."); return; }
      if (offerPriceNum >= priceNum) { setFormError("Offer Price normal Selling Price se kam hona chahiye."); return; }
      if (!offerStart || !offerEnd) { setFormError("Offer ki Start aur End date/time dono daalein."); return; }
      if (new Date(offerEnd) <= new Date(offerStart)) { setFormError("Offer End time, Start time se baad ka hona chahiye."); return; }
    }
    let cleanTiers = [];
    if (qtyTiers.length > 0) {
      for (const t of qtyTiers) {
        const q = Number(t.qty), p = Number(t.price);
        if (!t.qty || !t.price || isNaN(q) || isNaN(p) || q <= 0 || p <= 0) { setFormError("Buy More Save More ke sab tiers mein valid Qty aur Price bharein."); return; }
        cleanTiers.push({ qty: q, price: p });
      }
      cleanTiers.sort((a, b) => a.qty - b.qty);
      for (let i = 1; i < cleanTiers.length; i++) {
        if (cleanTiers[i].qty === cleanTiers[i - 1].qty) { setFormError("Do tiers ka Qty same nahi ho sakta."); return; }
      }
    }
    setSaving(true);
    await onSave({
      label, unit, price: priceNum, mrp: mrpNum, stock: stock === "" ? 0 : stockNum, barcode: barcode.trim() || null,
      offer_enabled: offerEnabled, offer_price: offerEnabled ? offerPriceNum : null,
      offer_starts_at: offerEnabled ? fromDatetimeLocal(offerStart) : null,
      offer_ends_at: offerEnabled ? fromDatetimeLocal(offerEnd) : null,
      qty_deal_tiers: cleanTiers,
      gst_rate: Number(gstRate) || 0,
    });
    setSaving(false);
  };

  return (
    <div style={{ background: "white", border: "1px solid #1B4332", borderRadius: "8px", padding: "10px", marginTop: "8px" }}>
      {prefillBarcode && (
        <div style={{ fontSize: "11px", color: "#1B4332", fontWeight: 600, marginBottom: "8px", background: "#E7F0EA", padding: "6px 9px", borderRadius: "6px" }}>
          ✓ Scan kiya hua barcode ({prefillBarcode}) is variant mein daal diya gaya hai
        </div>
      )}
      <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
        <Field label="Naam/Brand" value={label} onChange={setLabel} placeholder="jaise Normal, Premium, 1kg" />
        <div style={{ display: "flex", gap: "6px" }}>
          <div style={{ flex: 1 }}><UnitField businessType={businessType} value={unit} onChange={setUnit} /></div>
          <div style={{ flex: 1 }}><Field label="MRP (₹, optional)" value={mrp} onChange={(v) => setMrp(v.replace(/[^\d.]/g, ""))} placeholder="jaise 100" /></div>
          <div style={{ flex: 1 }}><Field label="Selling Price (₹)" value={price} onChange={(v) => setPrice(v.replace(/[^\d.]/g, ""))} /></div>
          <div style={{ flex: 1 }}><Field label="Stock" value={stock} onChange={(v) => setStock(v.replace(/\D/g, ""))} /></div>
        </div>
        {discount && (
          <div style={{ fontSize: "11px", color: "#1B4332", fontWeight: 700, background: "#E7F0EA", borderRadius: "6px", padding: "5px 9px" }}>
            Customer ko dikhega: <s style={{ color: "#8B8576" }}>₹{discount.mrp}</s> ₹{discount.price} — {discount.pct}% OFF
          </div>
        )}
        {gstEnabled && <GstRateField value={gstRate} onChange={setGstRate} />}
        <Field label="Barcode (optional)" value={barcode} onChange={setBarcode} placeholder="jaise 8901234567890" />
        <LimitedTimeDealFields
          enabled={offerEnabled} onEnabledChange={setOfferEnabled}
          offerPrice={offerPrice} onOfferPriceChange={setOfferPrice}
          start={offerStart} onStartChange={setOfferStart}
          end={offerEnd} onEndChange={setOfferEnd}
          basePrice={price}
        />
        <QuantityDealFields tiers={qtyTiers} onChange={setQtyTiers} basePrice={price} />
      </div>
      {formError && <div style={{ color: "#B3261E", fontSize: "11px", marginTop: "6px" }}>{formError}</div>}
      <div style={{ display: "flex", gap: "8px", marginTop: "8px" }}>
        <button onClick={onCancel} style={{ flex: 1, background: "#F7F5F0", border: "1px solid #E3DECF", borderRadius: "7px", padding: "7px 0", fontSize: "11.5px", fontWeight: 700, color: "#5C5747", cursor: "pointer" }}>Cancel</button>
        <button disabled={!valid || saving} onClick={handleSave} className="ddemo-btn" style={{ flex: 1, background: valid ? "#1B4332" : "#D8D2BF", color: "white", border: "none", borderRadius: "7px", padding: "7px 0", fontSize: "11.5px", fontWeight: 700, cursor: valid ? "pointer" : "not-allowed" }}>
          {saving ? "..." : "Add Karein"}
        </button>
      </div>
    </div>
  );
}

// ============================================================
// SHARED
// ============================================================
// GST Rate dropdown — sirf tab dikhta hai jab store ne GST enable kiya ho
// (gstEnabled prop). Rate 0/5/12/18/28% mein se hi chuna ja sakta hai.
function GstRateField({ value, onChange }) {
  return (
    <div>
      <div style={{ fontSize: "11px", fontWeight: 600, color: "#5C5747", marginBottom: "4px" }}>GST Rate</div>
      <select value={value} onChange={(e) => onChange(e.target.value)} style={inputStyle}>
        {[0, 5, 12, 18, 28].map((r) => <option key={r} value={String(r)}>{r}%</option>)}
      </select>
    </div>
  );
}

function Field({ label, value, onChange, placeholder, textarea }) {
  return (
    <div>
      <div style={{ fontSize: "11px", fontWeight: 600, color: "#5C5747", marginBottom: "4px" }}>{label}</div>
      {textarea ? (
        <textarea value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} rows={2} style={inputStyle} />
      ) : (
        <input value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} style={inputStyle} />
      )}
    </div>
  );
}

// Pehle Unit sirf free-text tha ("kg, litre, piece" placeholder) — ab
// business type ke hisaab se ek dropdown milta hai, taaki charge-basis
// (kg/litre/piece/pair/service/etc) hamesha consistent likha jaaye.
// "Custom" abhi bhi hai un cheezon ke liye jo list mein nahi hain.
function UnitField({ businessType, value, onChange }) {
  const presets = getUnitPresets(businessType);
  const [customMode, setCustomMode] = useState(value ? !presets.includes(value) : false);

  return (
    <div>
      <div style={{ fontSize: "11px", fontWeight: 600, color: "#5C5747", marginBottom: "4px" }}>Unit</div>
      {customMode ? (
        <div style={{ display: "flex", gap: "4px" }}>
          <input value={value} onChange={(e) => onChange(e.target.value)} placeholder="jaise quintal, meter" style={inputStyle} />
          <button type="button" onClick={() => { setCustomMode(false); onChange(presets[0]); }} title="List se chunein" style={{ ...iconBtnStyle, flexShrink: 0 }}>
            <ChevronDown size={14} />
          </button>
        </div>
      ) : (
        <select
          value={presets.includes(value) ? value : ""}
          onChange={(e) => {
            if (e.target.value === "__custom__") { setCustomMode(true); onChange(""); }
            else onChange(e.target.value);
          }}
          style={inputStyle}
        >
          <option value="" disabled>Chunein</option>
          {presets.map((u) => <option key={u} value={u}>{u}</option>)}
          <option value="__custom__">Other (khud likhein)</option>
        </select>
      )}
    </div>
  );
}

const inputStyle = { width: "100%", border: "1px solid #E3DECF", borderRadius: "7px", padding: "8px 10px", fontSize: "12.5px", fontFamily: "inherit", outline: "none" };
const iconBtnStyle = { width: 28, height: 28, borderRadius: "6px", border: "1px solid #E3DECF", background: "white", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", color: "#5C5747" };
const arrowBtnStyle = { width: 18, height: 15, borderRadius: "3px", border: "none", background: "#F0EEE6", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", color: "#5C5747", padding: 0 };
